package com.example.Project1Task3;

public class Result {
    public static int numA = 0;
    public static int numB = 0;
    public static int numC = 0;
    public static int numD = 0;
}
