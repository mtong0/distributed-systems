package cmu.edu.Task2;
/**
 * Name: Muyu Tong
 * Andrew ID: muyut
 * */
public class Latency {
    long latency;

    public Latency(){}
    public Latency(long latency) {
        this.latency = latency;
    }

    public long getLatency() {
        return latency;
    }

    public void setLatency(long latency) {
        this.latency = latency;
    }
}
